package com.bangkit.ch2_ps178_android.data.dataclass


data class PaymentResponse(
    val token: String
)
