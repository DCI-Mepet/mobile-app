package com.bangkit.ch2_ps178_android.data.dataclass

data class MainAdapterRowStatis(
    val id : String,
    val img : String,
    val judul : String,
    val konten : String,
)